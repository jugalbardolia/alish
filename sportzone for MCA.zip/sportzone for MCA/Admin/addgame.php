<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Game</title>
    
    <?php
        include('include/head.php');
    ?>

</head>
<body>
    <?php
        if(isset($_POST['addnewgamesubmit'])) {
            include('include/connection.php');

            $gamelabel=$_POST['gamelabel'];
            $gamename=$_POST['gamename'];
            $eventdate=$_POST['eventdate'];
            $venue=$_POST['venue'];
            $rules=$_POST['rules'];
            $details=$_POST['details'];
            $noofplayer=$_POST['noofplayer'];

            $maxserialqry= "select max(serial) from events";
            $maxserialres = mysqli_query($conn,$maxserialqry);
            $maxserial = mysqli_fetch_array($maxserialres);

            $serial = $maxserial[0] + 1;

            $qry = "INSERT INTO events (label,game,eventdatetime,venue,rules,details,status,serial,noofplayer) 
            values ('$gamelabel','$gamename','$eventdate','$venue','$rules','$details','A', $serial, $noofplayer)";
            $sql = mysqli_query($conn,$qry);

            echo "<script>window.location.href='managegames.php';</script>";
        }
    ?>
    <?php
        include('include/header.php');
    ?>
    <main>
        <div class="page-address">
            <span>/ <a href="managegames.php">Manage Games</a> / <a href="addgame.php">Add New Game</a></span>
        </div>
        <div class="main-container">
            <div class="page-heading">
                <h3>Add New Game Event</h3>
            </div>
            <div class="form-container">
                <form action="" method="post" name="addnewgame">
                    <div class="form-wrapper">
                        <div class="form-element-group">
                            <label class="form-label" for="">Game Label *</label>
                            <input type="text" name="gamelabel" id="gamelabel" class="form-input" placeholder="Enter The Game Label" required>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Game Name *</label>
                            <input type="text" name="gamename" class="form-input" placeholder="Enter The Game Name" required>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Event Date *</label>
                            <input type="datetime-local" name="eventdate" class="form-input" required>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Venue *</label>
                            <textarea name="venue" class="form-input form-textarea" id="" placeholder="Enter Venue Details" required></textarea>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">No of Player *</label>
                            <input type="number" name="noofplayer" class="form-input" value="0" required>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Rules *</label>
                            <textarea name="rules" class="form-input form-textarea" id="" placeholder="Enter Rules and Regulations Details" required></textarea>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Details</label>
                            <textarea name="details" class="form-input form-textarea" id="" placeholder="Enter Extra Details"></textarea>
                        </div>
                        <button type="submit" name="addnewgamesubmit" class="button1">Save</button>
                        <a href="managegames.php" class="button1 button1-cancel">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>
    
    <script>
        activateLink('managegames');

        document.getElementById('gamelabel').focus();
    </script>
</body>
</html>