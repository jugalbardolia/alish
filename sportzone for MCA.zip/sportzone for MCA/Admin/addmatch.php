<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Scoreboard</title>
    
    <?php
        include('include/head.php');
    ?>

</head>
<body>
    <?php
    include('include/connection.php');
        if(isset($_GET['id'])) {
            $id= $_GET['id'];

            $scoreboardstr = "select * from scoreboard where id = $id";
            $scoreboardqry = mysqli_query($conn,$scoreboardstr);
            $scoreboarddata = mysqli_fetch_array($scoreboardqry);

            $eventstr = "select * from participatepar where eventid =".$scoreboarddata['eventid'];
            $eventqry = mysqli_query($conn,$eventstr);
            $eventqry2 = mysqli_query($conn,$eventstr);
           
        }
    ?>

    <?php
        

        if(isset($_POST['addnewscoreboard'])) {

            $team1=$_POST['team1'];
            $team2=$_POST['team2'];

            $qry = "INSERT INTO scoreboardchild (team1id,team2id,parid) 
            values ($team1,$team2,$id)";
            $sql = mysqli_query($conn,$qry);

            echo "<script>window.location.href='managescore.php?id=$id';</script>";
        }
    ?>
    <?php
        include('include/header.php');
    ?>
    <main>
        <div class="page-address">
        <span>/ <a href="scorelist.php">List Of Scoreboards</a> / <a href="viewscoreboard.php?id=<?=$id?>">View Scoreboard (<?=$id?>)</a> / <a href="managescore.php?id=<?=$id?>">View Scoreboard (<?=$id?>)</a> / <a href="addmatch.php?id=<?=$id?>">Add New Match (<?=$id?>)</a></span>
        </div>
        <div class="main-container">
            <div class="page-heading">
                <h3>Add New Scoreboard</h3>
            </div>
            <div class="form-container">
                <form action="" method="post" name="addnewgame">
                    <div class="form-wrapper">
                        <div class="form-element-group">
                            <label class="form-label" for="">Team 1 *</label>
                            <select name="team1" id="" class="form-input">
                                <option value="">Select Event</option>
                                <?php
                                     while($eventdata = mysqli_fetch_assoc($eventqry)) {
                                ?>
                                        <option value="<?=$eventdata['id']?>"><?=$eventdata['teamname']?></option>
                                <?php
                                    }
                                ?>
                            </select>
                        </div>
                        
                        <div class="form-element-group">
                            <label class="form-label" for="">Team 2 *</label>
                            <select name="team2" id="" class="form-input">
                                <option value="">Select Event</option>
                                <?php
                                     while($eventdata2 = mysqli_fetch_assoc($eventqry2)) {
                                ?>
                                        <option value="<?=$eventdata2['id']?>"><?=$eventdata2['teamname']?></option>
                                <?php
                                    }
                                ?>
                            </select>
                        </div>
                        <button type="submit" name="addnewscoreboard" class="button1">Save</button>
                        <a href="scorelist.php" class="button1 button1-cancel">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>
    
    <script>
        activateLink('score');

        document.getElementById('gamelabel').focus();
    </script>
</body>
</html>