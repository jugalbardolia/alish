<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Scoreboard</title>
    
    <?php
        include('include/head.php');
    ?>

</head>
<body>
    <?php
        include('include/connection.php');
        if(isset($_POST['addnewscoreboard'])) {

            $label=$_POST['label'];
            $eventid=$_POST['eventid'];
            $status=$_POST['status'];

            $qry = "INSERT INTO scoreboard (label,eventid,status) 
            values ('$label',$eventid,'$status')";
            $sql = mysqli_query($conn,$qry);

            echo "<script>window.location.href='scorelist.php';</script>";
        }
    ?>
    <?php
        include('include/header.php');
    ?>
    <main>
        <div class="page-address">
            <span>/ <a href="scorelist.php">List Of Scoreboards</a> / <a href="addgame.php">Add New Scoreboard</a></span>
        </div>
        <div class="main-container">
            <div class="page-heading">
                <h3>Add New Scoreboard</h3>
            </div>
            <div class="form-container">
                <form action="" method="post" name="addnewgame">
                    <div class="form-wrapper">
                        <div class="form-element-group">
                            <label class="form-label" for="">Label *</label>
                            <input type="text" name="label" id="label" class="form-input" placeholder="Enter The Game Label" required>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Event *</label>
                            <select name="eventid" id="" class="form-input">
                                <option value="">Select Event</option>
                                <?php
                                    $str ="select * from events where eventdatetime >= NOW() and id not in (select eventid from scoreboard) order by serial DESC";
                                    $qry = mysqli_query($conn,$str);
                                    while($data = mysqli_fetch_assoc($qry)) {
                                ?>
                                        <option value="<?=$data['id']?>"><?=$data['label']?> [<?=$data['game']?>] (<?=$data['eventdatetime']?>)</option>
                                <?php
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Status</label>
                            <select name="status" id="" class="form-input">
                                <option value="inactive">Inactive</option>
                                <option value="active">active</option>
                            </select>
                        </div>
                        <button type="submit" name="addnewscoreboard" class="button1">Save</button>
                        <a href="scorelist.php" class="button1 button1-cancel">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>
    
    <script>
        activateLink('score');

        document.getElementById('gamelabel').focus();
    </script>
</body>
</html>