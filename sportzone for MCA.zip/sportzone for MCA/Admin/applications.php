<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    
    <?php
        include('include/head.php');
    ?>
   
    <link rel="stylesheet" href="css/applications.css">
</head>
<body>
    <?php
        include('include/header.php');
    ?>
    
    <main>
        <div class="page-address">
            <span>/ <a href="application.php">Applications</a></span>
        </div>
        <div class="main-container">
            <div class="page-heading">
                <h3>Applications</h3>
            </div>
            <div class="game-events">
                <div class="events-list">
                    <?php
                    include('include/connection.php');
                        $str = "select a.id as eventid, count(b.id) as ttlparts, a.serial, a.label, a.game, a.eventdatetime, a.venue 
                                from events as a
                                inner join participatepar as b on a.id = b.eventid
                                where a.eventdatetime >= NOW()
                                group by a.id
                                order by serial DESC";
                        $qry = mysqli_query($conn,$str);
                        
                        while($data = mysqli_fetch_assoc($qry)) {
                    ?>
                    <a href="viewparticipations.php?eventno=<?=$data['eventid']?>" class="event">
                        <div class="event-details">
                            <div class="event-head">
                                <h3 class="event-number">#<?=$data['serial']?></h3>
                                <h3><?=$data['label']?> <?=$data['eventdatetime']?></h3>
                            </div>
                        <span><?=$data['game']?></span></br>
                        <span><?=$data['venue']?></span>
                        </div>
                        <div class="event-indicator"><span><?=$data['ttlparts']?></span> &#8250;</div>
                    </a>
                    <?php
                        }
                    ?>

                </div>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>
    
    <script>
        activateLink('applications');
    </script>
</body>
</html>