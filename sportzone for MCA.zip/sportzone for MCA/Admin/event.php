<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Event</title>
    
    <?php
        include('include/head.php');
    ?>

</head>
<body>
    <?php
        include('include/connection.php');

        if(isset($_GET['eventid'])) {
            $disabled = "";
            if(isset($_GET['disabled'])) {
                $disabled = "disabled";
            }

            $id = $_GET['eventid'];
            if(isset($_POST['updategamesubmit'])) {
                $gamelabel=$_POST['gamelabel'];
                $gamename=$_POST['gamename'];
                $eventdate=$_POST['eventdate'];
                $venue=$_POST['venue'];
                $rules=$_POST['rules'];
                $details=$_POST['details'];
                $status=$_POST['status'];
                $noofplayer=$_POST['noofplayer'];


                $qry = "UPDATE events set label = '$gamelabel', game = '$gamename',
                eventdatetime = '$eventdate', venue = '$venue', rules = '$rules', details = '$details', status = '$status', 
                noofplayer=$noofplayer where id = $id";

                $sql = mysqli_query($conn,$qry);

                echo "<script>window.location.href='managegames.php';</script>";
            } else if (isset($_POST['deletegamesubmit'])) {
                $str = "select * from participatepar where eventid = $id";
                $qry = mysqli_query($conn,$str);
                if(mysqli_num_rows($qry) > 0) {
                    echo "<script>alert('Cannot be deleted, There are particiaptions');</script>";
                } else {   
                    $str = "delete from events where id  = $id";
                    $qry = mysqli_query($conn,$str);
                }
            } 

            $qry = "select * from events where id = $id";
            $sql = mysqli_query($conn,$qry);
            $data = mysqli_fetch_array($sql);
            
            if(count($data) == 0) {
                echo "<script>window.location.href='managegames.php';</script>";
            }

        } else {
            echo "<script>window.location.href='managegames.php';</script>";
        }
    ?>
    <?php
        include('include/header.php');
    ?>
    <main>
        <div class="page-address">
            <span>/ <a href="managegames.php">Manage Games</a> / <a href="event.php?eventid=<?=$data['id']?>">Update Event (<?=$data['serial']?>)</a></span>
        </div>
        <div class="main-container">
            <div class="page-heading">
                <h3>Update Game Event</h3>
            </div>
            <div class="form-container">
                <form action="" method="post" name="addnewgame">
                    <div class="form-wrapper">
                        <div class="form-element-group">
                            <label class="form-label" for="">Status</label>
                            <select class="form-input" name="status" <?=$disabled?>>
                                <?php
                                    $status = $data['status'];
                                    if($status=='A') {
                                        ?>
                                        <option value="A">Active</option>
                                        <option value="I">Inactive</option>
                                        <?php
                                    } else {
                                        ?>
                                        <option value="I">Inactive</option>
                                        <option value="A">Active</option>
                                        <?php
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Game Label *</label>
                            <input type="text" name="gamelabel" id="gamelabel" class="form-input" value="<?=$data['label']?>" placeholder="Enter The Game Label" required <?=$disabled?>>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Game Name *</label>
                            <input type="text" name="gamename" class="form-input" value="<?=$data['game']?>" placeholder="Enter The Game Name" required <?=$disabled?>>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Event Date *</label>
                            <input type="datetime-local" name="eventdate" class="form-input" value="<?=$data['eventdatetime']?>" required <?=$disabled?>>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Venue *</label>
                            <textarea name="venue" class="form-input form-textarea" id="" placeholder="Enter Venue Details" required <?=$disabled?>><?=$data['venue']?></textarea>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">No of Player *</label>
                            <input type="number" name="noofplayer" class="form-input" value="<?=$data['noofplayer']?>" required <?=$disabled?>>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Rules *</label>
                            <textarea name="rules" class="form-input form-textarea" id="" placeholder="Enter Rules and Regulations Details" required <?=$disabled?>><?=$data['rules']?></textarea>
                        </div>
                        <div class="form-element-group">
                            <label class="form-label" for="">Details</label>
                            <textarea name="details" class="form-input form-textarea" id="" placeholder="Enter Extra Details" <?=$disabled?>><?=$data['details']?></textarea>
                        </div>
                        <button type="submit" name="updategamesubmit" class="button1" <?=$disabled?>>Update</button>
                        <button type="submit" name="deletegamesubmit" class="button1" <?=$disabled?>>Delete</button>
                        <a href="managegames.php" class="button1 button1-cancel">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>
    
    <script>
        activateLink('managegames');

        document.getElementById('gamelabel').focus();
    </script>
</body>
</html>