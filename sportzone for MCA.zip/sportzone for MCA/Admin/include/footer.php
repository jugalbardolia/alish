<footer>
    <span>Developed By <b>Alish Mevawala</b></span>
</footer>