<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    
    <?php
        include('include/head.php');
    ?>

    <link rel="stylesheet" href="css/managegames.css">
</head>
<body>
    <?php
        include('include/connection.php');
    ?>
     
    <?php
        include('include/header.php');
    ?>

    <?php
    $searchtext = "";
    if(isset($_POST['eventsearchsubmit'])) {
        $searchtext = $_POST['eventserachtxt'];
    }
    ?>
    <main>
        <div class="page-address">
            <span>/ <a href="managegames.php">Manage Games</a></span>
        </div>
        <div class="main-container">
            <div class="page-heading">
                <h3>Manage Games</h3>
            </div>
            <div class="game-events">
                <a href="addgame.php" class="button1">+ Add New</a>
                <div class="events-list">
                    <div class="search-container">
                        <div class="form-container">
                            <form action="" method="post" name="addnewgame">
                                <div class="form-wrapper">
                                    <div class="form-element-group">
                                        <input type="text" name="eventserachtxt" id="eventserachtxt" class="form-input" placeholder="Search" value="<?=$searchtext?>" required>
                                        <button class="button1" name="eventsearchsubmit">Search</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <?php
                        if(isset($_POST['eventsearchsubmit'])) {
                            $query = "select * from events where eventdatetime >= NOW() and (label like '%$searchtext%' or game like '%$searchtext%') group by id order by serial DESC";
                        } else {
                            $query = "select * from events where eventdatetime >= NOW() order by serial DESC";
                        }
                            $res = mysqli_query($conn,$query);
                            while($eventsdata = mysqli_fetch_assoc($res)) {
                                $inactive="";
                                if($eventsdata['status'] != 'A') {
                                    $inactive = "inactive";
                                }
                    ?>
                    <a href="event.php?eventid=<?=$eventsdata['id']?>" class="event">
                        <div class="event-details">
                            <div class="event-head">
                                <h3 class="event-number <?=$inactive?>">#<?=$eventsdata['serial']?></h3>
                                <div>
                                    <h3><?=$eventsdata['label']?> [ <?=$eventsdata['game']?> ]</h3>
                                    <span>Date and Time: <?=$eventsdata['eventdatetime']?> Location: <?=$eventsdata['venue']?></span>
                                    <span class="ellipsis"><?=$eventsdata['rules']?></span>
                                </div>
                            </div>
                        </div>
                        <div class="event-indicator">&#8250;</div>
                    </a>
                    <?php
                        }
                    ?>
                </div>
            </div>
            <div class="game-events">
                <div class="events-list">
                <div class="page-heading">
                    <h3>Past Games Events</h3>
                </div>
                    <?php
                        $query = "select * from events where eventdatetime <= NOW() order by serial DESC";
                        $res = mysqli_query($conn,$query);
                        while($eventsdata = mysqli_fetch_assoc($res)) {
                    ?>
                    <a href="event.php?eventid=<?=$eventsdata['id']?>&disabled=true" class="event past">
                        <div class="event-details">
                            <div class="event-head">
                                <h3 class="event-number">#<?=$eventsdata['serial']?></h3>
                                <div>
                                    <h3><?=$eventsdata['label']?> [ <?=$eventsdata['game']?> ]</h3>
                                    <span>Date and Time: <?=$eventsdata['eventdatetime']?> Location: <?=$eventsdata['venue']?></span>
                                    <span class="ellipsis"><?=$eventsdata['rules']?></span>
                                </div>
                            </div>
                        </div>
                        <div class="event-indicator">&#8250;</div>
                    </a>
                    <?php
                        }
                    ?>
                </div>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>
    
    <script>
        activateLink('managegames');
    </script>
</body>
</html>