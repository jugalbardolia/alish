<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    
    <?php
        include('include/head.php');
    ?>
</head>
<body>
    <?php
        include('include/header.php');
    ?>
    <?php
        include('include/connection.php');
    ?>
    <?php
        if(isset($_GET['id'])) {
            $id=$_GET['id'];
        } else {
            echo "<script>window.location.href='scorelist.php';</script>";
        }
    ?>

    
<link rel="stylesheet" href="css/managegames.css">
    <main>
        <div class="page-address">
        <span>/ <a href="scorelist.php">List Of Scoreboards</a> / <a href="viewscoreboard.php?id=<?=$id?>">View Scoreboard (<?=$id?>)</a> / <a href="managescore.php?id=<?=$id?>">View Scoreboard (<?=$id?>)</a></span>
        </div>
        <div class="main-container">
        <div class="page-heading">
                <h3>Manage Scoreboards</h3>
            </div>
            <div class="game-events">
                <a href="addmatch.php?id=<?=$id?>" class="button1">+ Add New</a>
                <div class="events-list">
                    <?php
                            $query = "select * from scoreboardchild where winnerid = 0 order by id DESC";
                            $res = mysqli_query($conn,$query);
                            while($matchdata = mysqli_fetch_assoc($res)) {
                                $t1str = "select * from participatepar where id =".$matchdata['team1id'];
                                $t1qry = mysqli_query($conn,$t1str);
                                $t1data = mysqli_fetch_array($t1qry);
                                
                                $t2str = "select * from participatepar where id =".$matchdata['team2id'];
                                $t2qry = mysqli_query($conn,$t2str);
                                $t2data = mysqli_fetch_array($t2qry);
                                
                    ?>
                            <a href="viewscoreboard.php?id=<?=$matchdata['id']?>" class="event">
                                <div class="event-details">
                                    <div class="event-head">
                                        <h3 class="event-number">#<?=$matchdata['id']?></h3>
                                        <div>
                                            <h3><?=$t1data['teamname']?> Vs <?=$t2data['teamname']?></h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="event-indicator">&#8250;</div>
                            </a>
                    <?php
                        }
                    ?>
                </div>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>

    <script>
        activateLink('home');
    </script>
</body>
</html>