<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    
    <?php
        include('include/head.php');
    ?>
</head>
<body>
    <?php
        include('include/header.php');
    ?>
    <?php
        if(isset($_GET['parid'])) {
            include('include/connection.php');
            $parid = $_GET['parid'];

            $str = "select * from participatepar where id = $parid";
            $qry = mysqli_query($conn,$str);
            $data = mysqli_fetch_array($qry);

        } else {
            echo "<script>window.location.href='applications.php';</script>";
        }
    ?>
    <main>
        <div class="page-address">
            <span>/ <a href="applications.php">Applications</a> / <a href="viewparticipations.php?eventno=<?=$data['eventid']?>">Participations</a> / <a href="participantsdetails.php?parid=<?=$parid?>">Participants Details</a></span>
        </div>
        <div class="main-container">
        <div class="table-container">
                <table>
                    <?php
                        if($data['teamname']!="") {
                    ?>
                    <tr>
                        <th>Team Name</th>
                        <td><?=$data['teamname']?></td>
                    </tr>
                    <?php
                        }
                    ?>
                    <tr>
                        <th>Details</th>
                        <td><?=$data['details']?></td>
                    </tr>
                    
                    <tr>
                        <th>#</th>
                        <th>Players Name</th>
                    </tr>
                    
                    <?php
                        $playersstr = "select * from participatechild where parid = $parid";
                        $playersqry = mysqli_query($conn,$playersstr);
                        
                        while($playersdata = mysqli_fetch_assoc($playersqry)) {
                            ?>
                            <tr>
                                <th>Player <?=$playersdata['srl']?></th>
                                <td><?=$playersdata['playername']?></td>
                            </tr>
                    <?php
                        }
                    ?>
                </table>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>

    <script>
        activateLink('applications');
    </script>
</body>
</html>