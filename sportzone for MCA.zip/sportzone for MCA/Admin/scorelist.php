<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    
    <?php
        include('include/head.php');
    ?>

    <link rel="stylesheet" href="css/managegames.css">
</head>
<body>
    <?php
        include('include/connection.php');
    ?>
    
    <?php
        include('include/header.php');
    ?>

    <?php
    $searchtext = "";
    if(isset($_POST['scoreboardsearchsubmit'])) {
        $searchtext = $_POST['scoreboardtxt'];
    }
    ?>
    <main>
        <div class="page-address">
            <span>/ <a href="managegames.php">List Of Scoreboards</a></span>
        </div>
        <div class="main-container">
            <div class="page-heading">
                <h3>Manage Scoreboards</h3>
            </div>
            <div class="game-events">
                <a href="addscoreboard.php" class="button1">+ Add New</a>
                <div class="events-list">
                    <div class="search-container">
                        <div class="form-container">
                            <form action="" method="post" name="addnewgame">
                                <div class="form-wrapper">
                                    <div class="form-element-group">
                                        <input type="text" name="scoreboardtxt" id="scoreboardtxt" class="form-input" placeholder="Search" value="<?=$searchtext?>" required>
                                        <button class="button1" name="scoreboardsearchsubmit">Search</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <?php
                        if(isset($_POST['scoreboardsearchsubmit'])) {
                            $query = "select * from scoreboard where status = 'active' and (label like '%$searchtext%' or game like '%$searchtext%') group by id order by serial DESC";
                        } else {
                            $query = "select * from scoreboard where status = 'active' order by id DESC";
                        }
                            $res = mysqli_query($conn,$query);
                            while($sbdata = mysqli_fetch_assoc($res)) {
                    ?>
                    <a href="viewscoreboard.php?id=<?=$sbdata['id']?>" class="event">
                        <div class="event-details">
                            <div class="event-head">
                                <h3 class="event-number">#<?=$sbdata['id']?></h3>
                                <div>
                                    <h3><?=$sbdata['label']?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="event-indicator">&#8250;</div>
                    </a>
                    <?php
                        }
                    ?>
                </div>
            </div>
            <div class="game-events">
                <div class="events-list">
                <div class="page-heading">
                    <h3>Inactive Scoreboards</h3>
                </div>
                    <?php
                        $query = "select * from scoreboard where status = 'inactive' order by id DESC";
                        $res = mysqli_query($conn,$query);
                        while($sbdata = mysqli_fetch_assoc($res)) {
                    ?>
                    <a href="viewscoreboard.php?id=<?=$sbdata['id']?>&disabled=true" class="event past">
                        <div class="event-details">
                        <div class="event-head">
                                <h3 class="event-number">#<?=$sbdata['id']?></h3>
                                <div>
                                    <h3><?=$sbdata['label']?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="event-indicator">&#8250;</div>
                    </a>
                    <?php
                        }
                    ?>
                </div>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>
    
    <script>
        activateLink('score');
    </script>
</body>
</html>