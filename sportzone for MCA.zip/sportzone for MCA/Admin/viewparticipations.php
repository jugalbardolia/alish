<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    
    <?php
        include('include/head.php');
    ?>
    <link rel="stylesheet" href="css/applications.css">
</head>
<body>
    <?php
        include('include/header.php');
    ?>
    <main>
        <?php
            include('include/connection.php');
            $eventid = 0;
            if($_GET['eventno']) {
                $eventid = $_GET['eventno'];
            } else {
                echo "<script>window.location.href='applications.php';</script>";
            }
        ?>
        <div class="page-address">
            <span>/ <a href="applications.php">Applications</a> / <a href="viewparticipations.php?eventno=<?=$eventid?>">Participations</a></span>
        </div>
        <div class="main-container">
            <div class="page-heading">
                <h3>Participation List</h3>
            </div>
            <?php
                $eventstr = "select * from events where id  = $eventid";
                $eventqry = mysqli_query($conn,$eventstr);
                $eventdata = mysqli_fetch_array($eventqry);
            ?>
            <div class="table-container">
                <table>
                    <tr>
                        <th>Evnet Label</th>
                        <td><?=$eventdata['label']?></td>
                    </tr>
                    <tr>
                        <th>Game</th>
                        <td><?=$eventdata['game']?></td>
                    </tr>
                    <tr>
                        <th>Date</th>
                        <td><?=$eventdata['eventdatetime']?></td>
                    </tr>
                    <tr>
                        <th>Venue</th>
                        <td><?=$eventdata['venue']?></td>
                    </tr>
                    <tr>
                        <th>Rules</th>
                        <td><?=$eventdata['rules']?></td>
                    </tr>
                    <tr>
                        <th>Details</th>
                        <td><?=$eventdata['details']?></td>
                    </tr>
                </table>
            </div>
            <div class="game-events">
                <div class="events-list">
                    <?php
                        $str = "select a.id, a.teamname, b.fname, b.lname, a.details
                        from participatepar as a
                        left join users as b on a.userid = b.id
                        where a.eventid = $eventid";
                        $qry = mysqli_query($conn,$str);
                        
                        while($data = mysqli_fetch_assoc($qry)) {
                    ?>
                    <a href="participantsdetails.php?parid=<?=$data['id']?>" class="event">
                        <div class="event-details">
                            <div class="event-head">
                                <h3 class="event-number">
                                    <?php
                                        if($data['teamname'] != '') {
                                    ?>
                                    Team Name: <?=$data['teamname']?>
                                    <?php
                                        } else {
                                            $playersrl= "select * from participatechild where parid = ".$data['id']." and srl= 1";
                                            $playerqry = mysqli_query($conn,$playersrl);
                                            $playerdata = mysqli_fetch_array($playerqry);
                                    ?>
                                    Player : <?=$playerdata['playername']?>
                                    <?php
                                        }
                                    ?>
                                </h3>
                            </div>
                            <h3>Application By : <?=$data['fname']?> <?=$data['lname']?> </h3>
                            <span><?=$data['details']?></span>
                        </div>
                        <div class="event-indicator">&#8250;</div>
                    </a>
                    <?php
                        }
                    ?>

                </div>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>
    
    <script>
        activateLink('applications');
    </script>
</body>
</html>