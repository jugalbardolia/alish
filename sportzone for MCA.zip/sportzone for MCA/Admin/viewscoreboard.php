<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Scoreboard</title>
    
    <?php
        include('include/head.php');
    ?>

</head>
<body>
    <?php
        include('include/connection.php');

        if(isset($_GET['id'])) {

            $id = $_GET['id'];

            if(isset($_POST['updatescoreboardsubmit'])) {
                $label=$_POST['label'];
                $eventid=$_POST['eventid'];
                $status=$_POST['status'];

                $qry = "UPDATE scoreboard set label = '$label', status = '$status',
                eventid=$eventid where id = $id";

                $sql = mysqli_query($conn,$qry);

                echo "<script>window.location.href='scorelist.php';</script>";
                
            } else if (isset($_POST['deletescoreboardsubmit'])) {
                $str = "delete from scoreboard where id = $id";
                $qry = mysqli_query($conn,$str);
            } 

            $qry = "select * from scoreboard where id = $id";
            $sql = mysqli_query($conn,$qry);
            $data = mysqli_fetch_array($sql);
            
            if(count($data) == 0) {
                echo "<script>window.location.href='scorelist.php';</script>";
            }

        } else {
            echo "<script>window.location.href='scorelist.php';</script>";
        }
    ?>
    <?php
        include('include/header.php');
    ?>
    <main>
        <div class="page-address">
            <span>/ <a href="scorelist.php">List Of Scoreboards</a> / <a href="viewscoreboard.php?id=<?=$id?>">View Scoreboard (<?=$id?>)</a></span>
        </div>
        <div class="main-container">
            <div class="page-heading">
                <h3>Update Game Event</h3>
            </div>
            <div class="form-container">
                <form action="" method="post" name="addnewgame">
                    <div class="form-wrapper">
                        <div class="form-element-group">
                            <label class="form-label" for="">Label *</label>
                            <input type="text" name="label" id="label" value="<?=$data['label']?>" class="form-input" placeholder="Enter The Game Label" required>
                        </div>
                        
                        <div class="form-element-group">
                            <label class="form-label" for="">Event *</label>
                            <select name="eventid" id="" class="form-input">
                                <?php
                                    $str ="select * from events where id = ".$data['eventid'];
                                    $qry = mysqli_query($conn,$str);
                                    while($eventdata = mysqli_fetch_assoc($qry)) {
                                        ?>
                                        <option value="<?=$eventdata['id']?>"><?=$eventdata['label']?> [<?=$eventdata['game']?>] (<?=$eventdata['eventdatetime']?>)</option>
                                        <?php
                                    }
                                    ?>
                                <?php
                                    $str ="select * from events where eventdatetime >= NOW() and id not in (select eventid from scoreboard) order by serial DESC";
                                    $qry = mysqli_query($conn,$str);
                                    while($eventdata = mysqli_fetch_assoc($qry)) {
                                ?>
                                        <option value="<?=$eventdata['id']?>"><?=$eventdata['label']?> [<?=$eventdata['game']?>] (<?=$eventdata['eventdatetime']?>)</option>
                                <?php
                                    }
                                ?>
                            </select>
                        </div>
                        
                        <div class="form-element-group">
                            <label class="form-label" for="">Status</label>
                            <select class="form-input" name="status">
                                <?php
                                    $status = $data['status'];
                                    if($status=='active') {
                                        ?>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                        <?php
                                    } else {
                                        ?>
                                        <option value="inactive">Inactive</option>
                                        <option value="active">Active</option>
                                        <?php
                                    }
                                ?>
                            </select>
                        </div>

                        <div class="" style="display:flex;justify-content:space-between">
                        <div class="">
                            <button type="submit" name="updatescoreboardsubmit" class="button1">Update</button>
                            <button type="submit" name="deletescoreboardsubmit" class="button1">Delete</button>
                            <a href="scorelist.php" class="button1 button1-cancel">Cancel</a>
                        </div>
                        <a href="managescore.php?id=<?=$id?>" class="button1">Manage Score</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>
    
    <script>
        activateLink('score');

        document.getElementById('gamelabel').focus();
    </script>
</body>
</html>