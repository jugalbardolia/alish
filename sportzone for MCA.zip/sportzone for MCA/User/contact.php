<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
</head>
<body>
    <div>
        <h1>Contact Us</h1>
        <h3>Name: Alish Mevawala</h3>
        <h3>Mobile No: 8877556644</h3>
        <h3>Email Address: alish@gmail.com</h3>
        <h3>Address: Akshya Nagar 1st Block 1st Cross, Rammurthy nagar,Vesu,Surat</h3>
    </div>
    
</body>
</html>