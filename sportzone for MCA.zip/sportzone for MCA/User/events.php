<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    
    <?php
        include('include/head.php');
    ?>
    <link rel="stylesheet" href="css/events.css">
</head>
<body>
    <?php
        include('include/header.php');
    ?>

    <?php
        include('include/connection.php');
    ?>
    <main>
        <div class="main-container">
            <div class="events-container">

                <?php
                    $qry = "select * from events where eventdatetime >= NOW() and status = 'A' order by serial DESC";
                    $sql = mysqli_query($conn,$qry);
                    while($data = mysqli_fetch_assoc($sql)) {
                ?>    
                <div class="event-card">
                    <div class="event-image">
                        <span class="event-serial">#<?=$data['serial']?></span>
                        <img src="images/match-banner1.jpg" alt="">
                    </div>
                    <div class="event-details">
                        <div class="event-header">
                            <h4><?=$data['label']?></h4>
                        </div>
                        <div class="event-game">
                            <span><?=$data['game']?></span>
                        </div>
                        <div class="event-date">
                            <?=$data['eventdatetime']?>
                        </div>
                        <div class="event-venue">
                            <?=$data['venue']?>
                        </div>
                        <div class="event-more">
                            <a href="viewevent.php?eventid=<?=$data['id']?>">More Details</a>
                        </div>
                    </div>
                </div>
                <?php
                    }
                ?>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>

    <script>
        activateLink('events');
    </script>
</body>
</html>