<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    
    <?php
        include('include/head.php');
    ?>

    <link rel="stylesheet" href="css/participate.css">
</head>
<body>
    <?php
        include('include/header.php');
    ?>
    <?php
        include('include/connection.php');

        if(isset($_GET['eventid'])) {
            $id = $_GET['eventid'];
            $str = "select * from events where id = $id";
            $qry = mysqli_query($conn,$str);
            $data = mysqli_fetch_array($qry);
        } else {
            echo "<script>window.location.href='events.php';</script>";
        }

        if(isset($_POST['partproceed'])) {
            $teamname = $_POST['teamname'];
            $details = $_POST['details'];
            $str = "INSERT INTO participatepar (teamname, details, eventid, userid) values ('$teamname','$details', ". $_GET['eventid'] .", ".$userdata['id'].");";
            $qry = mysqli_query($conn,$str);

            $parid = mysqli_insert_id($conn);

            $playername= "";

            for($i=0;$i<$data['noofplayer'];$i++) {
                $playername = $_POST['player_' . ($i+1)];
                $str = "INSERT INTO participatechild (playername,srl,parid) values ('$playername',". ($i+1) .", $parid);";
                $qry = mysqli_query($conn,$str);
            }
        }
    ?>
    <main>
        <div class="main-container">
            <div class="event-detail-container">
                <div class="event-label">
                    <h3>#<?=$data['serial']?> <?=$data['label']?></h3>
                </div>
                <div class="event-game">
                    <span><?=$data['game']?></span>
                </div>
                <div class="event-date">
                    <span><?=$data['eventdatetime']?></span>
                </div>
                <div class="event-venue">
                    <span><?=$data['venue']?></span>
                </div>
            </div>
            <div class="participate-form">
                <div class="page-heading">
                    <h3>Participation Form</h3>
                </div>
                <div class="form-container">
                <form action="" method="post" name="participation">
                    <div class="form-wrapper">
                        <?php
                                $disnone="";
                                if($data['noofplayer']==1) {
                                    $disnone = "display:none;";
                                }
                                ?>
                        <div style="<?=$disnone?>" class="form-element-group">
                            <label class="form-label" for="">Team Name</label>
                            <input type="text" name="teamname" id="teamname" class="form-input" placeholder="Enter Team Name">
                        </div>
                        
                            <?php
                                for($i=0;$i<$data['noofplayer'];$i++) {
                                    ?>
                            <div class="form-element-group">
                                <label class="form-label" for="">Player <?=$i+1?></label>
                                <input type="text" name="player_<?=$i+1?>" id="player_<?=$i+1?>" class="form-input" placeholder="Enter Player <?=$i+1?> Name" required>
                            </div>
                                                        
                            <?php
                                }
                            ?>
                        <div class="form-element-group">
                            <label class="form-label" for="">Details</label>
                            <textarea name="details" class="form-input form-textarea" id="" placeholder="Write some details to make your profile more strong to be selected" required></textarea>
                        </div>
                        <button type="submit" name="partproceed" class="button1">Proceed</button>
                        <a href="managegames.php" class="button1 button1-cancel">Cancel</a>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>

    <script>
        activateLink('events');
    </script>
</body>
</html>