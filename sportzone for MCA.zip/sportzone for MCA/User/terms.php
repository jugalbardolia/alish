<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
</head>
<body>
    <div>
        <h1>Terms & Conditions:-</h1>
    </div>
    <div>
    <ul class="icon-list">
                              <li><i class="fa fa-angle-right"></i>Once match is booked cannot be canceled.</li>
                              <li><i class="fa fa-angle-right"></i>If canceled, No Refund will be given.</li>
                              <li><i class="fa fa-angle-right"></i>All sports equipments available here.</li>
							  <li><i class="fa fa-angle-right"></i>No excahnge or retrun will be done.</li>
							  <li><i class="fa fa-angle-right"></i>All types of payments acceptable here(COD,Online payment, Net Banking, Debit Card, Credit Card, Wallets).</li>
							  <li><i class="fa fa-angle-right"></i>There will be no change in the match once confirmed.</li>
							  <li><i class="fa fa-angle-right"></i>All above terms and condition applies.</li>
                           </ul>
    </div>
</body>
</html>