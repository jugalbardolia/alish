<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    
    <?php
        include('include/head.php');
    ?>

    <link rel="stylesheet" href="css/viewevent.css">
</head>
<body>
    <?php
        include('include/header.php');
    ?>
    <?php
        if(isset($_GET['eventid'])) {
            include('include/connection.php');
            $id = $_GET['eventid'];

            $qry = "select * from events where id = $id";
            $sql = mysqli_query($conn,$qry);
            $data = mysqli_fetch_array($sql);
        } else {
            echo "<script>window.location.href='events.php';</script>";
        }
    ?>
    <main>
        <div class="main-container">
            <div class="viewevent-container">
                <div class="participate-container">
                    <div class="event-image">
                        <img src="images/match-banner1.jpg" alt="">
                    </div>
                    <div class="participate-button">
                        <?php
                        if(!isset($_SESSION['userid'])) {
                        ?>
                        <a href="#" class="button1">Sign Up</a> or
                        <a href="#" class="button1">Login</a> to participate
                        <?php
                        } else {
                        ?>
                        <a href="participate.php?eventid=<?=$data['id']?>" class="button1">Participate</a>
                        <?php
                        }
                        ?>
                    </div>
                    <div class="event-terms">
                        <ul>
                            <li>There will be a payment, which you will have to pay.</li>
                            <li>Registration cannot be cancelled when maximum 5 days remain.</li>
                            <li>If anyhow you cancel registration, only 70% of payment will refundable.</li>
                        </ul>
                    </div>
                </div>
                <div class="event-detail-container">
                    <div class="event-label">
                        <h3>#<?=$data['serial']?> <?=$data['label']?></h3>
                    </div>
                    <div class="event-game">
                        <span><?=$data['game']?></span>
                    </div>
                    <div class="event-date">
                        <span><?=$data['eventdatetime']?></span>
                    </div>
                    <div class="event-venue">
                        <span><?=$data['venue']?></span>
                    </div>
                    <div class="event-rules">
                        <h4>Rules</h4>
                        <span><?=$data['rules']?></span>    
                    </div>
                    <div class="event-details">
                        <h4>Details</h4>
                        <span><?=$data['details']?></span>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php
        include('include/footer.php');
    ?>

    <script src="js/main.js"></script>

    <script>
        activateLink('events');
    </script>
</body>
</html>